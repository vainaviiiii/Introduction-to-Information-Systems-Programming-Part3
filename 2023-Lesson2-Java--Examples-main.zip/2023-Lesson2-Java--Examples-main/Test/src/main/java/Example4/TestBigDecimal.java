package Example4;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class TestBigDecimal {

    public static void main(String[] args) {

        /*******
         * Have a look at how bank interest is calculated
         * https://www.posb.com.sg/Resources/posb/docs/deposit/termsupdate.pdf
         */

        // TODO write a static method to add two ints.
        // can you guarantee that it always returns the correct answer?
        System.out.println(add(20000000, 200000000));
        //it result in overflow because the sum exceeded the maximum int possible
        System.out.println(Integer.MAX_VALUE);

        // TODO Instantiate two BigDecimal objects
        BigDecimal a = new BigDecimal("8");
        BigDecimal b = new BigDecimal("5");
        BigDecimal c = a.add(b);    // a new object is returned
        BigDecimal d = a.subtract(b);
        //result in error bcz got infinite decimal
        MathContext mc = new MathContext(5, RoundingMode.HALF_UP);
        BigDecimal e = a.divide(c, mc); //need to specify the MathContext
        // TODO Then write code to add subtract multiply divide and compare
        //BigDecimal is Comparable!
        System.out.println(a.compareTo(b));
        // 1 if it is larger, -1 if it is smaller
    }
    //static factory method
    static int add(int a, int b){
        return a + b;
    }
}
