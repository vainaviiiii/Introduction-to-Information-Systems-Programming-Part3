package Example2;

public class Tea {

    private boolean sugar;
    private boolean milk;

    /**constructor could be private - means to force users to use your static factory methods
     */
    Tea( boolean sugar, boolean milk){
        this.sugar = sugar;
        this.milk = milk;
    }

    /**Limiting the situation in which your object can be instantiated
     */
    // TODO Write the static factory methods
    public static Tea giveMeTehO(){  //return type is Tea
        return new Tea(true, false);    //you give your user guidance on how use the constructor
    }
    public static Tea giveMeTehKosong(){
        return new Tea(false, true);
    }

    // TODO Write toString()    -- exercise for you
    @Override
    public String toString(){
        return super.toString();
    }
}
