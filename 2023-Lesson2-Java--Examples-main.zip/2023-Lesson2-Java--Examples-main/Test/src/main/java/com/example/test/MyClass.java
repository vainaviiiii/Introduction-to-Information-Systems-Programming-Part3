package com.example.test;

public class MyClass {

    // Nothing to see here
}