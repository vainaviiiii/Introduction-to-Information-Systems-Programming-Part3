package Example3;

public class Tea {

    private boolean sugar;
    private boolean milk;

    private boolean ice;

    //constructor with 3 inputs
    /**Tea( boolean sugar, boolean milk, boolean ice){
        this.sugar = sugar;
        this.milk = milk;
    }*/

    Tea(TeaBuilder teaBuilder){
        this.sugar = teaBuilder.sugar;
        this.milk = teaBuilder.milk;
        this.ice = teaBuilder.ice;
    }

    //how if there are many possible inputs to the constructor? how to solve? -- builder design pattern
    static class TeaBuilder{
        /** has some internal fields as the outside class*/
        private boolean sugar;
        private boolean milk;
        private boolean ice;

        TeaBuilder(){}  //No-arg constructor

        /** setter for each field returns the same instance of the Builder class */
        public TeaBuilder setSugar(boolean sugar){
            this.sugar = sugar;
            return this;    //you return the same instance  -- why? -- so that you can call it again with another setter
        }

        public TeaBuilder setMilk(boolean milk){
            this.milk = milk;
            return this;    //you return the same instance  -- why? -- so that you can call it again with another setter
        }

        public TeaBuilder setIce(boolean ice){
            this.ice = ice;
            return this;    //you return the same instance  -- why? -- so that you can call it again with another setter
        }

        /** Once all the setters are called, this build()  method to create the object
         * builder class --> it supposed to create object of Tea
         */
        public Tea build(){
            return new Tea(this);
        }
    }

    // TODO Write the nested class to implement the builder design pattern



}
