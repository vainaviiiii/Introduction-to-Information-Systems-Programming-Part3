package Example3;

public class TestTea {
    public static void main(String[] args) {
        Tea.TeaBuilder teaBuilder = new Tea.TeaBuilder();
        //teaBuilder object and setSugar also return teaBuilder object and build method return object of the Tea class

        //builder design pattern -- constructors with many many options
        Tea tea = teaBuilder.setSugar(true).setMilk(true).setIce(false).build();

        /** alternativelu:
         * Tea tea = new Tea.TeaBuilder().setSugar(true).setMilk(true).setIce(false).build();
         */
    }
}
