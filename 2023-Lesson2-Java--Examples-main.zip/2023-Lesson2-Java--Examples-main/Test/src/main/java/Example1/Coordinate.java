package Example1;

public class Coordinate {

    private double x, y;

    Coordinate(double x, double y){
        this.x = x;
        this.y = y;
    }

    /**************
     *  Should I put getters and setters?
     *  True - Yes
     *  False - No
     */
}
