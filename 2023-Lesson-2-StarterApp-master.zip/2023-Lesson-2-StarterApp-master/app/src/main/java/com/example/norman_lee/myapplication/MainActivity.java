package com.example.norman_lee.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //in this example the name of the id and the instance variable name (below) are the same
    Button buttonConvert;
    Button buttonSetExchangeRate;
    EditText editTextValue;
    TextView textViewResult;
    TextView textViewExchangeRate;
    //double exchangeRate;  <-- change to object declare
    public final String TAG = "Logcat";
    private SharedPreferences mPreferences;
    private String sharedPrefFile = "com.example.android.mainsharedprefs";
    public static final String RATE_KEY = "Rate_Key";
    ExchangeRate exchangeRate; // <--

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //TODO 4.5 Get a reference to the sharedPreferences object
        //TODO 4.6 Retrieve the value using the key, and set a default when there is none
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        /** app is already been used, or app is used for the first time */
        String exchangeRateString = mPreferences.getString(RATE_KEY,
                getString(R.string.default_exchange_rate));

        //TODO 3.13 Get the intent, retrieve the values passed to it, and instantiate the ExchangeRate class
        Intent subToMain = getIntent();
        /*****
         * 1. This is the //explicit intent with data being passedfirst time the app is started --> no intent --> no data
         * 2. The app is in use, the user has just entered the values in SubActivity
         *  --> there is intent and data
         */

        //second case
        String home = subToMain.getStringExtra(SubActivity.HOME_KEY);
        String foreign = subToMain.getStringExtra(SubActivity.FOREIGN_KEY);

        //distinguish whether we are in the first scenario or second scenario:
        if(home == null || foreign == null){
            //exchangeRate = new ExchangeRate();  // <-- MOVED from 2.2
            //changed (above) to using constructor in the ExchangeRate that has one input
            exchangeRate = new ExchangeRate(exchangeRateString);    // <-- MODIFIED
        }
        else{
            exchangeRate = new ExchangeRate(home, foreign);
        }

        //TODO 3.13a See ExchangeRate class --->

        /**
         * 1. back to here using an Intent --> data is available in the intent
         * 2. app is started for the first time --> no data is available
         * --> user click an icon on phone --> data comes from SharedPreferences  (when i didnt get data from the intent, thats when i click on the phone
         * data came from SharedPreferences
         * i.e. default exchange rate
         */

        //TODO 2.1 Use findViewById to get references to the widgets in the layout
        buttonConvert = findViewById(R.id.buttonConvert);
        //TODO 3.2
        buttonSetExchangeRate = findViewById(R.id.buttonSetExchangeRate);
        editTextValue = findViewById(R.id.editTextValue);
        textViewExchangeRate = findViewById(R.id.textViewExchangeRate);
        textViewResult = findViewById(R.id.textViewResult);
        //TODO 2.2 Assign a default exchange rate of 2.95 to the textView
        //textViewExchangeRate.setText(R.string.default_exchange_rate); <-- change to do something else by declaring the ExchangeRate object
        //instead of using the hidden string (above) we change to (below)
        //using exchangeRate class and instantiate a default ExchangeRate

        //get the exchangeRate by using the ExchangeRate method and passed it toString and get the exchnageRate
        textViewExchangeRate.setText(exchangeRate.getExchangeRate().toString());


        //TODO 2.3 Set up setOnClickListener for the Convert Button
        buttonConvert.setOnClickListener(new View.OnClickListener() {
            //anonymous inner class
            @Override
            public void onClick(View view) {
                //todo 2.4
                String amount = editTextValue.getText().toString();
                if(amount.isEmpty()){
                    Toast.makeText(MainActivity.this, R.string.empty_edit_text,
                            Toast.LENGTH_LONG).show();
                }

                //todo 2.5
                else{
                    //user enter the amount and calculated
                    String result = exchangeRate.calculateAmount(amount).toString();
                    //put it back to the UI --> displayed in textViewResult
                    textViewResult.setText(result);
                }
            }
        });
        //TODO 2.4 Display a Toast & Logcat message if the editTextValue widget contains an empty string
        //TODO 2.5 If not, calculate the units of B with the exchange rate and display it
        //TODO 2.5a See ExchangeRate class --->


        //TODO 3.1 Modify the Android Manifest to specify that the parent of SubActivity is MainActivity
        //at the AndroidManifest folder
        //TODO 3.2 Get a reference to the Set Exchange Rate Button
        //TODO 3.3 Set up setOnClickListener for this
        //TODO 3.4 Write an Explicit Intent to get to SubActivity
        buttonSetExchangeRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //TODO 3.4

                // MainActiviy.this because you are in an inner class
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                startActivity(intent);
            }
        });

        // ensure that the menu is present (it is generated in BasicActivity)
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // it is the pink button floating
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //TODO 4.1 Go to res/menu/menu_main.xml and add a menu item Set Exchange Rate

    //TODO 4.2 In onOptionsItemSelected, add a new if-statement and code accordingly

    //TODO 5.1 Go to res/menu/menu_main.xml and add a menu item Open Map App
    //TODO 5.2 In onOptionsItemSelected, add a new if-statement
    //TODO 5.3 code the Uri object and set up the intent


    //the menu item to respond when you click it (below)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        /** example for you, does nothing */
        if (id == R.id.action_settings) {
            return true;
        }
        if ( id == R.id.menu_set_exchange_rate){
            Intent intent = new Intent(this, SubActivity.class);
            startActivity(intent);
            return true;
        }

        //implicit intent in opening google maps
        if (id == R.id.menu_open_google_maps){
            //build the uri to specify the location
            Uri.Builder uriBuilder = new Uri.Builder();
            /** geo:0.0?1=ChangiAirport*/
            uriBuilder.scheme("geo").opaquePart("0.0")
                    .appendQueryParameter("q", "ChangiAirport");  //here we hardcode the location ChangiAirport
            //Uri object
            Uri uri = uriBuilder.build();
            Toast.makeText(this, uri.toString(), Toast.LENGTH_LONG).show();

            //the implicit intent code
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(uri);
            //check if the phone has a map app (because sometimes a phone dont have it
            if (intent.resolveActivity(getPackageManager())!= null){
                startActivity(intent);
            }
        }

        return super.onOptionsItemSelected(item);
    }

    //TODO 4.3 override the methods in the Android Activity Lifecycle here
    //TODO 4.4 for each of them, write a suitable string to display in the Logcat

    //TODO 4.7 In onPause, get a reference to the SharedPreferences.Editor object
    //TODO 4.8 store the exchange rate using the putString method with a key

}
