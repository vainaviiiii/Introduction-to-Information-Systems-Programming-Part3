package com.example.norman_lee.myapplication;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class ExchangeRate {

    private BigDecimal exchangeRate;
    private static String defaultRate = "2.95000";
    private static final int DEFAULT_PRECISION = 5;
    private int precision = DEFAULT_PRECISION;
    private MathContext mathContext;

    //constructor that has the defaultRate
    ExchangeRate(){
        exchangeRate = new BigDecimal(defaultRate);
        instantiateMathContext(DEFAULT_PRECISION);  //mathContext --> restrict the number of the decimal has
    }
    //constructor that has the exchangeRate

    ExchangeRate(String exchangeRate){
        this.exchangeRate = new BigDecimal(exchangeRate);
        instantiateMathContext(DEFAULT_PRECISION);
    }

    //modify this constructor to calculate the exchange rate so you can use the correct exchange rate
    ExchangeRate(String home, String foreign) {

        instantiateMathContext(DEFAULT_PRECISION);
        //TODO 3.13a The constructor initializes exchangeRate by calculating the exchangeRate
        /**
         * home = foreign* (home/foreign)
         */
        BigDecimal homeCurrency = new BigDecimal(home);
        BigDecimal foreignCurrency = new BigDecimal(foreign);
        exchangeRate = homeCurrency.divide(foreignCurrency, mathContext);

        //exchangeRate = new BigDecimal(defaultRate);
    }

    BigDecimal getExchangeRate(){
        return exchangeRate;
    }

    BigDecimal calculateAmount(String foreign){
        //TODO 2.5a complete this method to return the amount
        BigDecimal foreignCurrency = new BigDecimal(foreign);
        BigDecimal homeCurrency = foreignCurrency.multiply(exchangeRate, mathContext);
        return homeCurrency;

        //return BigDecimal.ZERO;
    }

    void setPrecision(int precision){
        this.precision = precision;
        instantiateMathContext(precision);
    }

    private void instantiateMathContext(int precision){
        mathContext = new MathContext(precision, RoundingMode.HALF_UP);
    }

    //TODO 2.5b override toString() to provide information on the exchange rate
}
