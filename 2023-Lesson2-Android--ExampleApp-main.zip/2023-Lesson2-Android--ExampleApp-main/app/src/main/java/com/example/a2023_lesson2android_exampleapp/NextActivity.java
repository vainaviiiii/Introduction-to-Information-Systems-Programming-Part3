package com.example.a2023_lesson2android_exampleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class NextActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);


        /**MainActivity has an intent to got o NextActivity and passed some data*/
        //We are in NextActivity to receive data passed to it via an intent
        Intent intent = getIntent();
        //retrieve the data passed as a string (can passed it as other type as well)
        //the key was a static variable in the MainActivity
        //and it can be passed to another variable --> message in this example
        String message = intent.getStringExtra(MainActivity.TAG);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();    //display a Toast

        //TODO Write intent to get to MainActivity -- try yourself

    }
}