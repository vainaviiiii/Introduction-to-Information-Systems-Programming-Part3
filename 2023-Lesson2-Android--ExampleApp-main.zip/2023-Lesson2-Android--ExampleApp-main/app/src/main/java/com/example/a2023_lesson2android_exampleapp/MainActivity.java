package com.example.a2023_lesson2android_exampleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //how to write code in a button?

    //instantiate button
    Button buttonMain;

    static String TAG = "Testing";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate()");

        //TODO Write intent to get to Next Activity
        buttonMain = findViewById(R.id.buttonMain);
        buttonMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //move from one activity to another --> intent
                //explicit intent (there is no data to pass)
                // origin (it's the class you are in and since we are in a class, we do ), destination
                //the MainActivity class is an anonymous inner class so to refer to the outer class, outer.this
                Intent intent = new Intent(MainActivity.this, NextActivity.class);
                //explicit intent (there's data to pass)
                intent.putExtra(TAG, "good afternoon");
                startActivity(intent);  //instance method
            }
        });

        //TODO Write code for a Toast


        //TODO (if there's time) Add a button to activate google maps
    }

    // TODO Override the methods of the android activity life cycle


    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onSResume()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop()");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause()");

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart()");
    }
}