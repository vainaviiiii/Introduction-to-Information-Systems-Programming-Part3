# PLEASE NOTE

In this repository, I provide access to my own firebase instance so that you can focus on the coding. This is done using a google-services.json file. 

I will close access shortly after the lesson is over. 

If you wish to continue working on this app, please create your own firebase instance at
* https:// console.firebase.google.com
* and follow the instructions there to generate your own google-services.json file to use in this project. 