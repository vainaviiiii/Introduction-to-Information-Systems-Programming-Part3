package com.example.lesson4examples;

public class MyClass {
}