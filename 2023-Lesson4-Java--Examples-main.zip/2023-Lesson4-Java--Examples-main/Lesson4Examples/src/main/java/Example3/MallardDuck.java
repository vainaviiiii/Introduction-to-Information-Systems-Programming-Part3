package Example3;

public class MallardDuck implements Duck{
    @Override
    public void quack() {
        System.out.println("Quack");
    }

    @Override
    public void fly() {
        System.out.println("Fly");
    }
}

class PekingDuck implements Duck{

    @Override
    public void quack() {
        System.out.println("I have");

    }

    @Override
    public void fly() {
        System.out.println("I cannot ");

    }
}
