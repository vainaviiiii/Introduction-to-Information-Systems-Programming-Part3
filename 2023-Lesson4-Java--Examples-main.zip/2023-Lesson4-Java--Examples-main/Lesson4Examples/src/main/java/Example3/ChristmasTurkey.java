package Example3;

public class ChristmasTurkey implements Turkey{
    @Override
    public void gobble() {
        System.out.println("....");
    }

    @Override
    public void fly() {
        System.out.println("... aaaaa");
    }
}
