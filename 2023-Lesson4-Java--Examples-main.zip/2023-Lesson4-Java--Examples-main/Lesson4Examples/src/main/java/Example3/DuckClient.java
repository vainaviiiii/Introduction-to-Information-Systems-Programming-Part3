package Example3;

import java.util.ArrayList;
import java.util.List;

public class DuckClient {

    static List<Duck> myDucks;

    public static void main(String[] args) {
        myDucks = new ArrayList<>();
        myDucks.add(new MallardDuck());
        myDucks.add(new PekingDuck());
        myDucks.add(new MallardDuck());
        myDucks.add(new TurkeyAdapter(new ChristmasTurkey()));
        makeDucksFlyQuack();
    }

    // TODO 1 Loop through myDucks and call fly() and quack()
    static void makeDucksFlyQuack(){
        for (Duck duck: myDucks){
            duck.fly();
            duck.quack();
        }
    }
}
