package Example3;

// TODO 2 TurkeyAdapter allows Turkey objects to behave like Duck ...

public class TurkeyAdapter implements Duck{

    /** This Adapter takles in a Turkey object and presents a Duck interface
     * Adapter Design Pattern - adapt one object to another object's interface
     */

    Turkey turkey;

    TurkeyAdapter(Turkey turkey){
        this.turkey = turkey;
    }
    @Override
    public void quack() {
        turkey.gobble();
    }

    @Override
    public void fly() {
        turkey.fly();
    }
}
