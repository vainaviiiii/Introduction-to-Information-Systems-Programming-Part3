package Example3;

public interface Duck {

    void quack();
    void fly();
}
