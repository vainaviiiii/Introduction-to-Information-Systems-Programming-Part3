package Example3;

interface Turkey {

    void gobble();
    void fly();
}
