package Example1;

import java.util.ArrayList;
import java.util.List;

public class PhoneBook {

    /*** this example shows one use of nested classes
     *  which is as a data model  (nested class -> to store data)
     *  since the PhoneBook relies on Entry to store data,
     *  it would make sense to make Entry as a nested class in PhoneBook
     *
     *  Would you like SimpleEntry to be Comparable or Entry to be Comparable?
     *  What's the difference?
     */


    //put Comparable<Entry> on the interface, do you want all of your supertype to be comparable or only your concrete class to be comparable?
    //all objects Comparable if you implement Comparable here
    interface Entry {
        String getName();
        String getPhoneNumber();
    }

    private List<Entry> entryList;

    // TODO 1 Complete the constructor to initialize entryList
    PhoneBook(){    /**program to your supertype */
        entryList = new ArrayList<>();
    }

    // TODO 2 Complete addEntry to add a phoneBook entry
    void addEntry(String name, String number){
        //you have SimpleEntry constructor with name and number so
        entryList.add(new SimpleEntry(name, number));
    }

    // TODO 3 What if you'd like to be able to sort phonebook entries by name?

    //static inner class that implements the interface
    //put as nested class -> you you can see the relationship straight away
    static class SimpleEntry implements Entry, Comparable<Entry>{
        private String name, number;

        SimpleEntry(String name, String number ){
            this.name = name;
            this.number = number;

        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public String getPhoneNumber() {
            return number;
        }

        @Override
        public String toString() {
            return name + ":" + number;
        }
        @Override
        public int compareTo(Entry entry){
            return this.getName().compareTo(entry.getName());
        }
    }

}
