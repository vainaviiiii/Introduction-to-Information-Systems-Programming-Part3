package Example2;

public class TestDuck {

    public static void main(String[] args) {
        Duck myDuck = new MallardDuck("Norman");
        /** This is Strategy Design Pattern
         * Behaviours that could change are encapsulated in objects
         * Fly behaviour is delegated to objects that implement the FlyBehaviour interface
         * --> allows run-time changes
         * */
        myDuck.setFlyBehaviour(new MallardDuckFly());
        myDuck.setQuackBehaviour(new MallardDuckQuack());

        myDuck.fly();
        myDuck.quack();
        myDuck.display();
    }
}
