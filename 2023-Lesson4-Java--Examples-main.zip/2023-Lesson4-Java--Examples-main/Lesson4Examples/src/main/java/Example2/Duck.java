package Example2;

public abstract class Duck {

    /** Nest these interfaces in Duck because they are related */
    interface FlyBehaviour{
        void fly();
    }

    interface QuackBehaviour{
        void quack();
    }

    private FlyBehaviour flyBehaviour;
    private QuackBehaviour quackBehaviour;
    private String name;

    //force the behaviour to be forced to pass to the instantiation
    public Duck(String name){
        this.name = name;
        this.flyBehaviour = new FlyBehaviour() {
            @Override
            public void fly() {
                System.out.println("fly");
            }
        };
    }

    // TODO 1 write setters for FlyBehaviour and QuackBehaviour
    public void setFlyBehaviour(FlyBehaviour flyBehaviour){
        this.flyBehaviour = flyBehaviour;
    }

    public void setQuackBehaviour(QuackBehaviour quackBehaviour) {
        this.quackBehaviour = quackBehaviour;
    }

    /** Call fly() before call setFlyBehaviour() --> object is null --> nUllPointer */
    // TODO 2 complete methods fly() and quack()

    public void fly(){
        if (flyBehaviour != null){
            flyBehaviour.fly();
        }
        else{

        }

    }

    public void quack(){
        quackBehaviour.quack();
    }

    public abstract void display();

    // TODO 3 Realize that there could be a problem if the client called fly() before calling set().

    // TODO 3 How would you solve the problem?

    /** 1. Force behaviours to be passed during instantiation
     *  2. Provide default behaviour during instantiation
     *  3. Check for null pointer before execution
     */

}
