package Example2;

public class MallardDuckFly implements Duck.FlyBehaviour{

    @Override
    public void fly() {
        System.out.println("ordelllll");
    }
}

class MallardDuckQuack implements Duck.QuackBehaviour{

    @Override
    public void quack() {
        System.out.println("fly flyyy");
    }
}
