package Example2;

public class MallardDuck extends Duck {

    public MallardDuck(String name){
        super(name);
    }

    @Override
    public void display() {
        System.out.println("ordel is ica");
    }

    //classes that related should be nested together
    //example
    static class MallardDuckFly implements Duck.FlyBehaviour{

        @Override
        public void fly() {

        }
    }

}
