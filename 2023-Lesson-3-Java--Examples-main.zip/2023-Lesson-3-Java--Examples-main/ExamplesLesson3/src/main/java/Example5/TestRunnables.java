package Example5;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestRunnables {

    public static void main(String[] args){

        /** YOU WANT ONE THREAD*/
        /** one thread got 2 processes*/
        // now nothing happen in parallel because only have 1 thread
        // 1 process is executed in sequence
        //ExecutorService executorService = Executors.newSingleThreadExecutor();
        /** YOU WANT TWO BACKGROUND THREADS */
        ExecutorService executorService = Executors.newFixedThreadPool(2);
        //it runs in parallel
        executorService.execute(new PrintStr("A", 20));
        executorService.execute(new PrintStr("B", 20));
        executorService.shutdown();
    }

}


/** modify to implement Runnable and the run() method  **/
class PrintStr implements Runnable{

    String s;
    int times;

    PrintStr(String s, int times){
        this.s = s;
        this.times = times;
    }

    /** String s -- prefix letter e.g. A
     * times - number of iterations
     * run() e.g. s is A and times is 20, we will see
     * A0, A1, A2 .... A18 A19
     */

    //write background task
    @Override
    public void run() {
        for(int i =0; i<times; i++){
            System.out.print(s + i + " ");
        }
        System.out.println("END");

    }
}
