package Example2;

public abstract class CaffeineBeverage {

    /** The template method design pattern is a pattern where
     * An algorithm has a set of fixed steps. The implementation of each step could vary.
     *
     * In the following class,
     * (a) Which method is the algorithm? -- prepareRecipe()
     * (b) which steps could vary? -- brew() and addCondiments()
     * but boilWater() and pourInCup() also can vary because you can override it
     */

    final void prepareRecipe(){
        boilWater();
        brew();
        addCondiments();
        pourInCup();
    }
    abstract void brew();

    abstract void addCondiments();

    void boilWater(){
        System.out.println("boiling water");
    }

    void pourInCup(){
        System.out.println("pouring in cup");
    }
}
class AnyhowCoffee extends CaffeineBeverage{

    @Override
    void brew() {
        System.out.println("pouurrrr");
    }
    @Override
    void addCondiments() {
        System.out.println("aiyaaaaaa");
    }
}
