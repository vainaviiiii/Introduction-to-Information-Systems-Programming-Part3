package Example2;

public class GourmetCoffee {
}
