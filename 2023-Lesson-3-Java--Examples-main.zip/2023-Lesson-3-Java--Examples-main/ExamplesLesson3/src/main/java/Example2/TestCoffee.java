package Example2;

public class TestCoffee {
    public static void main(String[] args) {
        CaffeineBeverage coffee = new AnyhowCoffee();
        coffee.prepareRecipe();
    }
}
