package Example1;

public abstract class Feline {

    private String name;
    private String breed;

    /** put the constructor in!*/
    //abstract class can have constructor
    //abstract class cannot instantiate
    //so you need to subclass it to implement the abstract method
    Feline(String name, String breed){
        this.name = name;
        this.breed = breed;
    }

    public String getName() {
        return name;
    }

    public String getBreed() {
        return breed;
    }
    public abstract void sound();
}

class Tiger extends Feline{

    /**
     * put the constructor in!
     *
     * @param name
     * @param breed
     */
    //make your own constructor and then invoke the superclass constructor
    Tiger(String name, String breed) {

        super(name, breed); // <-- call your superclass constructor
    }

    @Override
    public void sound() {
        System.out.println("RAWR!");
    }

    //override the toString as well
    @Override
    public String toString(){
        return "Tiger" + this.getName()+ " " + getBreed();
    }   //getName() and getBreed() are inherited because they are public
}
