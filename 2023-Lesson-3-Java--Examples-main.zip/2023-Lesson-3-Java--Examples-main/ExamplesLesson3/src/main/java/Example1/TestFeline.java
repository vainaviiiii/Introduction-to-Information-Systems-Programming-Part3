package Example1;

import java.util.ArrayList;
import java.util.List;

public class TestFeline {

    public static void main(String[] args) {
        //Declare as a concrete type
        // -> it becomes not flexible
        // because if you want to change the implementation of the class
        // you need to change the whole thing
        Tiger tiger = new Tiger("Orange", "Sumatra");

        /** BETTER WAY TO DO - program to a supertype
         *  Assign to ANY class that extends Feline, not just Tiger
         *  **/
        //Tiger extends abstract class Feline
        // your code becomes more flexible

        //here you declare your variable as the supertype class
        //then you can assign any class that extends it, not just a concrete class
        //also applied to interfaces
        Feline tiger2 = new Tiger("Orange", "Sumatra");

        /** any object that extends Feline can be added to this arraylist */
        //ArrayList is a concrete implementation
        // List<> type is an interface
        //ArrayList<Feline> arrayList = new ArrayList<>();  <-- SHOULDNT DO THIS

        //INSTEAD:
        /**ArrayList is a concrete object that implements List interface*/
        List<Feline> arrayList = new ArrayList<>();
        arrayList.add(tiger2);

    }

}
