package Example4;

//two type of parameter
// Compare Pair object so implements Comparable
/** F extends Comparable<F> tells the compiler that type parameter F must be Comparable */
public class Pair <F extends Comparable<F>, S extends Comparable<S>> implements Comparable<Pair<F,S>>{

    private F first;
    private S second;

    Pair(F first, S second){
        this.first = first;
        this.second = second;
    }

    //TODO put the getters in yourselves

    //you want to swap --> you create a new object where S come first and F comes second
    public Pair<S,F> swap (){
        return new Pair(second, first);
    }

    public F getFirst() {
        return first;
    }

    public S getSecond() {
        return second;
    }

    @Override
    public int compareTo(Pair<F, S> fsPair) {
        /**
         * Two pair objects are the same if their F type have the same contents
         * if i want to use compareTo, then I must make sure that F are Comparable
         * but in this case, F don't have the compareTo
         * --> Place bounds on the Type Parameter (see above)
         * --> since I forced F to be Comparable, then first now has the compareTo method
         */
        return this.first.compareTo(fsPair.getFirst());
    }
}
