package Example4;

import java.math.BigDecimal;

public class TestPair {
    public static void main(String[] args) {
        Pair<Integer, BigDecimal> pair = new Pair<>(Integer.valueOf("1"),
                new BigDecimal("1"));
        Pair<BigDecimal, Integer> pair2 = pair.swap();

        /** F- Integer
         * S - BigDecimal
         */
    }
}
