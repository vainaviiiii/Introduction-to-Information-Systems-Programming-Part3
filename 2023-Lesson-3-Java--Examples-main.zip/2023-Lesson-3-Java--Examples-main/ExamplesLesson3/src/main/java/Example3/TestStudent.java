package Example3;

public class TestStudent {
    public static void main(String[] args) {

        /** KNOW YOUR HIERARCHY OF EXCEPTIONS */
        /** EXCEPTIONS you catch must be specific */

        /**try{
            Student student = new Student("Norman", "abcdef");
        }*/
        //you cannot do this
        //you cannot put your superclass first then your subclass because your superclass will catch everything
        /**catch(Exception e){
            e.printStackTrace();
        }
        catch (IllegalArgumentException e){
            e.printStackTrace();
        }*/

        //here java didnt have the try-catch block why?
        Student student = new Student("Norman", "abcdef");
        //because IllegalArgumentException is an unchecked Exception
        // --> not compulsory to have try-catch block

    }
}
