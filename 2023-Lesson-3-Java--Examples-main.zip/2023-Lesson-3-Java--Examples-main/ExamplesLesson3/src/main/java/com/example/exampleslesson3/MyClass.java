package com.example.exampleslesson3;

public class MyClass {

    // nothing to see here
}