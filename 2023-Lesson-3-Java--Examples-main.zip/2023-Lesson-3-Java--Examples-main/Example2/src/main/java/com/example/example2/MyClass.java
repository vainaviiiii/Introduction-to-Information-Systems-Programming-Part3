package com.example.example2;

public abstract class MyClass {
    /**int x = 0;  //declaring an instance variable

    abstract void f();  //must have no implementation because declared abstract
    void g();   //no abstract --> means needs an implementation

    abstract void h();*/
}